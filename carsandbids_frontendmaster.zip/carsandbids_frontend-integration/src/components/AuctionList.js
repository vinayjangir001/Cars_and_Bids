import { Component } from "react";
import Logo from "../images/logo.PNG";
import "../css/w3.css";
import SignupLoginModel from "./SignupLoginModel";
import CarBlock from "./CarBlock";
import DetailedAuction from "./DetailedAuction";
import { Link } from "react-router-dom";


class AuctionList extends Component{

    constructor(props){
        super(props);

        this.state = {
            carDetails : [],
            goToDetailedPage : false,
            detailedAuctionDetails: null,
            selectedYear: "",             // Selected year filter value
            selectedTransmissionType: "All", // Selected transmission type filter value
            selectedBodyStyle: "All"         // Selected body style filter value
        }

    }

    componentDidMount(){
        this.handleLogin();
    }

    // componentDidUpdate(prevProps){
    //   if(this.props.searchText!=null && this.props.searchText!="" && prevProps.searchText!=this.props.searchText){
    //     const data = this.state.carDetails.filter(a => a.car.carName.startsWith(this.props.searchText))
    //     this.setState({carDetails:null})
    //     this.setState({ carDetails: data});
    // }
    // }


    handleLogin = async () => {
        try {
          const { email, password } = this.state;
          const response = await fetch('http://localhost:8081/auction/all', {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
               'Accept-Encoding': 'gzip, deflate, br', // Comma-separated list of supported encodings
               'Connection': 'keep-alive'
            }
          });
    
          const data = await response.json();

          const liveAuctions = data.filter(item => item.auctionStatus === 'CREATED');

        
          this.setState({ carDetails: liveAuctions});


        } catch (error) {
          console.error('Error fetching data:', error);
        }
      };

      moveToDetailPage = (item) => {
          this.setState({detailedAuctionDetails: item,goToDetailedPage:true })
      }

      render() {
        const transmissionTypes = ["All", "Automatic", "Manual"];
        const bodyStyles = ["All", "Coupe", "Convertible", "Hatchback", "Sedan", "SUV", "Truck", "Van", "Wagon"];

        return (
            <>
                {/* Add the dropdown menus for filter search here */}
                <div class="w3-bar "> 
                <div class="w3-bar-item" >
                    <label>Year:</label>
                    <select value={this.state.selectedYear} name="selectedYear" onChange={(e) => {this.setState({ selectedYear: e.target.value, carDetails: [] }); this.handleLogin();}}>
                        <option value="">All Years</option>
                        {Array.from({ length: 2023 - 1980 }, (_, i) => 2023 - i).map((year, index) => (
                            <option key={index} value={year}>{year}</option>
                        ))}
                    </select>
                </div>
                <div class="w3-bar-item" >
                    <label>Transmission Type:</label>
                    <select value={this.state.selectedTransmissionType} name="selectedTransmissionType" onChange={(e) => {this.setState({ selectedTransmissionType: e.target.value, carDetails: [] }); this.handleLogin();}}>
                        {transmissionTypes.map((transmissionType, index) => (
                            <option key={index} value={transmissionType}>{transmissionType}</option>
                        ))}
                    </select>
                </div>
                <div class="w3-bar-item" >
                    <label>Body Style:</label>
                    <select value={this.state.selectedBodyStyle} name="selectedBodyStyle" onChange={(e) => {this.setState({ selectedBodyStyle: e.target.value, carDetails: [] }); this.handleLogin();}}>
                        {bodyStyles.map((bodyStyle, index) => (
                            <option key={index} value={bodyStyle}>{bodyStyle}</option>
                        ))}
                    </select>
                </div>
                </div>

                {/* Your car listing section */}
                {/* <div className="w3-row" style={{ width: "100vw" }}>
                    <div className="w3-col l9">
                        {this.state.carDetails
                            .filter(item => (!this.state.selectedMake || item.make === this.state.selectedMake) &&
                                (!this.state.selectedModel || item.model === this.state.selectedModel) &&
                                (!this.state.selectedYear || item.year === this.state.selectedYear))
                            .map((item) => (
                                <Link to={"/details/" + item.auctionId}>
                                    <div className="w3-card-4 w3-round-xlarge" style={{ width: "30%", height: "20rem", float: "left", margin: "1rem" }} onClick={() => this.moveToDetailPage(item)}>
                                        <CarBlock carData={item} />
                                    </div>
                                </Link>
                            ))}
                    </div> */}



        {<div className="w3-row" style={{width:"100vw"}}>
      <div className="w3-col l9">
      {/* {this.state.carDetails.map((item) => (
        <Link  to={"/details/"+item.auctionId}>
        <div className="w3-card-4 w3-round-xlarge" style={{width:"30%", height:"20rem", float:"left", margin:"1rem"}} onClick={() => this.moveToDetailPage(item)}>
            <CarBlock  carData={item} />
        </div>
        </Link>
      ))}
      </div> */}

{this.state.carDetails
                            .filter(item => (!this.state.selectedYear || item.car.year === parseInt(this.state.selectedYear)) &&
                                (this.state.selectedTransmissionType === "All" || item.car.transmissionType === this.state.selectedTransmissionType) &&
                                (this.state.selectedBodyStyle === "All" || item.car.bodyStyle === this.state.selectedBodyStyle))
                            .map((item) => (
                                <Link to={"/details/" + item.auctionId}>
                                    <div className="w3-card-4 w3-round-xlarge" style={{ width: "30%", height: "20rem", float: "left", margin: "1rem" }} onClick={() => this.moveToDetailPage(item)}>
                                        <CarBlock carData={new Object(item)} />
                                    </div>
                                </Link>
                            ))}
                    </div>
      <div className="w3-col l3" style={{height:"100%", overflow:"hidden",marginTop:"1rem"}}>
      <div style={{width:"90%",height:"100%"}}>
          <div style={{width:"100%",height:"20rem"}}>
      <iframe width="100%" height="100%" src="https://www.youtube.com/embed/rZZNEBMGvg4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
      </div>
      <h5>Cars & Bids is the best marketplace for modern enthusiast cars.</h5>
      </div>
      </div>
        </div>}</>
        )
    }
}


export default AuctionList;