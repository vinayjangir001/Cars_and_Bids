import logo from './logo.svg';
import './App.css';
import Header from './components/Header';
import SignupLoginModel from './components/SignupLoginModel';

function App() {
  return (
    <div className="App">
      <Header/>
    </div>
  );
}

export default App;
