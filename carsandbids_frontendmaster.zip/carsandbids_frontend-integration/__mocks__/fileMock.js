// __mocks__/styleMock.js

module.exports = 'test-file-stub';
