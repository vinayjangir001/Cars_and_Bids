package com.example.auctionbids;

import com.example.auctionbids.config.FileStorageProperties;
import org.junit.jupiter.api.Test;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuctionbidsApplicationTests {

	@Test
	void contextLoads() {
	}

}
