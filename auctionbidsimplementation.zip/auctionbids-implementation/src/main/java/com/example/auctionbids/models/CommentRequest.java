package com.example.auctionbids.models;

import lombok.Data;

@Data
public class CommentRequest {

    private String commentText;

}