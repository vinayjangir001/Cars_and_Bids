package com.example.auctionbids.enums;

public enum AuctionStatus {

    CREATED,
    OPEN,
    UPDATED,
    ENDED,
    CANCELLED;

}
